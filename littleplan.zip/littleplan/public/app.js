// ==========================================
//  app.js — LittlePlan main application
//  Works 100% without AI or a backend.
//  Drop in /public and open index.html.
// ==========================================

// ── STATE ───────────────────────────────
const STATE = {
  usedToday: 0,
  maxFree: 5,
  lastPlan: null
};

const LOAD_STEPS = [
  ["Building your plan…",       "Picking the perfect activities"],
  ["Matching to your child…",   "Filtering by age and interests"],
  ["Adding creative touches…",  "Almost ready!"],
];

// ── INIT ────────────────────────────────
window.addEventListener("DOMContentLoaded", () => {
  loadUsage();
  renderQuotaDots();

  // Pill toggle
  document.querySelectorAll(".pill").forEach(btn => {
    btn.addEventListener("click", () => {
      btn.classList.toggle("active");
    });
  });
});

// ── USAGE TRACKING (localStorage) ───────
function loadUsage() {
  const today = new Date().toDateString();
  const stored = JSON.parse(localStorage.getItem("lp_usage") || "{}");
  if (stored.date === today) {
    STATE.usedToday = stored.count || 0;
  } else {
    STATE.usedToday = 0;
    saveUsage();
  }
  renderQuotaDots();
}

function saveUsage() {
  localStorage.setItem("lp_usage", JSON.stringify({
    date: new Date().toDateString(),
    count: STATE.usedToday
  }));
}

function renderQuotaDots() {
  const container = document.getElementById("quota-dots");
  const label     = document.getElementById("quota-label");
  if (!container) return;
  container.innerHTML = "";
  for (let i = 0; i < STATE.maxFree; i++) {
    const d = document.createElement("div");
    d.className = "qdot" + (i < STATE.usedToday ? " used" : "");
    container.appendChild(d);
  }
  const left = Math.max(0, STATE.maxFree - STATE.usedToday);
  label.textContent = left > 0
    ? `${left} free plan${left !== 1 ? "s" : ""} left today`
    : "Daily limit reached — come back tomorrow!";
}

// ── PLAN GENERATION ──────────────────────
function generatePlan() {
  if (STATE.usedToday >= STATE.maxFree) {
    alert("You've used all 5 free plans today. Come back tomorrow for more!");
    return;
  }

  const age      = document.getElementById("f-age").value;
  const season   = document.getElementById("f-season").value;
  const activePills = [...document.querySelectorAll(".pill.active")].map(p => p.dataset.val);
  const interests = activePills.length ? activePills : ["art","science"];

  showLoading();

  // Simulate a brief loading delay so it feels magical
  let step = 0;
  const interval = setInterval(() => {
    if (step < LOAD_STEPS.length) {
      document.getElementById("loader-title").textContent = LOAD_STEPS[step][0];
      document.getElementById("loader-sub").textContent   = LOAD_STEPS[step][1];
      step++;
    } else {
      clearInterval(interval);
      const plan = buildPlan(age, season, interests);
      STATE.lastPlan = plan;
      STATE.usedToday++;
      saveUsage();
      renderQuotaDots();
      showResults(plan);
    }
  }, 550);
}

function buildPlan(age, season, interests) {
  // Filter activities by age
  let pool = ACTIVITIES.filter(a => a.ages.includes(age));

  // Season filter (keep "any" always, plus matching season)
  pool = pool.filter(a =>
    a.seasons.includes("any") ||
    a.seasons.includes(season) ||
    season === "any"
  );

  // Score by interest match
  const scored = pool.map(a => {
    const matches = a.interests.filter(i => interests.includes(i)).length;
    return { ...a, score: matches + Math.random() * 0.8 };
  });

  // Sort by score descending, deduplicate by name
  scored.sort((a, b) => b.score - a.score);

  // Pick 7 unique activities, biasing towards interest matches but ensuring variety
  const chosen = [];
  const usedCategories = {};

  for (const activity of scored) {
    if (chosen.length >= 7) break;
    // Allow max 3 of same category for variety
    const catCount = usedCategories[activity.category] || 0;
    if (catCount < 3) {
      chosen.push(activity);
      usedCategories[activity.category] = catCount + 1;
    }
  }

  // If we don't have 7 yet, fill with anything remaining
  if (chosen.length < 7) {
    for (const activity of scored) {
      if (chosen.length >= 7) break;
      if (!chosen.find(c => c.name === activity.name)) {
        chosen.push(activity);
      }
    }
  }

  // Pick a random week theme
  const theme = WEEK_THEMES[Math.floor(Math.random() * WEEK_THEMES.length)];

  // Pick 3 random tips
  const shuffledTips = [...TIPS].sort(() => Math.random() - 0.5).slice(0, 3);

  return { theme, days: chosen.slice(0, 7), tips: shuffledTips, age, interests, season };
}

// ── VIEWS ────────────────────────────────
function showLoading() {
  document.getElementById("form-view").classList.add("hidden");
  document.getElementById("results-view").classList.add("hidden");
  document.getElementById("loading-view").classList.remove("hidden");
}

function showResults(plan) {
  document.getElementById("loading-view").classList.add("hidden");
  document.getElementById("results-view").classList.remove("hidden");

  document.getElementById("theme-word").textContent = plan.theme;

  renderDays(plan.days);
  renderTips(plan.tips);

  // Scroll to results
  document.getElementById("tool-card").scrollIntoView({ behavior: "smooth", block: "start" });
}

function resetForm() {
  document.getElementById("results-view").classList.add("hidden");
  document.getElementById("loading-view").classList.add("hidden");
  document.getElementById("form-view").classList.remove("hidden");
}

// ── RENDERING ────────────────────────────
function renderDays(days) {
  const container = document.getElementById("days-list");
  container.innerHTML = "";

  days.forEach((activity, i) => {
    const day = DAYS[i];
    const card = document.createElement("div");
    card.className = `day-card d${i}`;
    card.style.animationDelay = `${i * 0.07}s`;

    const matsHtml = activity.materials
      .slice(0, 4)
      .map(m => `<span class="mtag">${m}</span>`)
      .join("");

    card.innerHTML = `
      <div class="dbadge">
        <span class="dname">${day.name}</span>
        <span class="dicon">${day.icon}</span>
      </div>
      <div class="dinfo">
        <div class="aname">${activity.name}</div>
        <div class="adesc">${activity.desc}</div>
        <div class="mats">${matsHtml}</div>
      </div>
      <div class="dmeta">
        <span class="dur">${activity.duration} min</span>
        <div class="cdot ${activity.category}"></div>
      </div>
    `;

    container.appendChild(card);
  });
}

function renderTips(tips) {
  const box = document.getElementById("tips-card");
  const tipsHtml = tips
    .map(t => `<div class="tip-row">${t}</div>`)
    .join("");

  box.innerHTML = `
    <div class="tips-title">💡 Tips for this week</div>
    ${tipsHtml}
  `;
}

// ── SHARE ────────────────────────────────
function sharePlan() {
  if (!STATE.lastPlan) return;

  // Encode the plan as a compact URL param so the link opens with the same plan
  const planData = {
    theme: STATE.lastPlan.theme,
    days: STATE.lastPlan.days.map(d => d.name),
    age: STATE.lastPlan.age
  };

  const encoded = btoa(encodeURIComponent(JSON.stringify(planData)));
  const shareUrl = `${window.location.origin}${window.location.pathname}?plan=${encoded}`;

  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(shareUrl).then(() => {
      showToast("Link copied! Share it with your co-parent or carer.");
    });
  } else {
    // Fallback
    prompt("Copy this link to share:", shareUrl);
  }
}

function showToast(msg) {
  let toast = document.getElementById("toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "toast";
    toast.style.cssText = `
      position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
      background: #1E1E2E; color: #fff; font-family: 'Nunito', sans-serif;
      font-size: 14px; font-weight: 700; padding: 12px 22px; border-radius: 30px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.25); z-index: 9999;
      transition: opacity .3s;
    `;
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.opacity = "1";
  setTimeout(() => { toast.style.opacity = "0"; }, 2800);
}

// ── RESTORE FROM URL ─────────────────────
// If someone opens a shared link, try to restore the plan
window.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const encoded = params.get("plan");
  if (!encoded) return;
  try {
    const planData = JSON.parse(decodeURIComponent(atob(encoded)));
    // Rebuild the plan from the same activities using stored day names
    if (planData.days && planData.age) {
      const activities = planData.days.map(name =>
        ACTIVITIES.find(a => a.name === name)
      ).filter(Boolean);

      if (activities.length >= 7) {
        const plan = {
          theme: planData.theme || "Explorers",
          days: activities.slice(0, 7),
          tips: [...TIPS].sort(() => Math.random() - 0.5).slice(0, 3),
          age: planData.age,
          interests: [],
          season: "any"
        };
        STATE.lastPlan = plan;
        showResults(plan);
      }
    }
  } catch (e) {
    // Shared link is malformed — just show the form as normal
  }
});
