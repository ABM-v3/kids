// ==========================================
//  activities.js — hand-picked activity bank
//  No AI needed. 80+ activities across all
//  age groups, interests, and categories.
// ==========================================

const WEEK_THEMES = [
  "Explorers", "Scientists", "Artists", "Adventurers",
  "Builders", "Naturalists", "Creators", "Investigators",
  "Champions", "Storytellers"
];

const DAYS = [
  { name: "Mon", icon: "🌅" },
  { name: "Tue", icon: "🌿" },
  { name: "Wed", icon: "⭐" },
  { name: "Thu", icon: "🌈" },
  { name: "Fri", icon: "🎉" },
  { name: "Sat", icon: "☀️" },
  { name: "Sun", icon: "🌙" }
];

// ── ACTIVITY LIBRARY ───────────────────────
// Each activity: { name, desc, materials, duration, category, interests[], ages[], seasons[] }
// ages: "2-3" | "4-6" | "7-9" | "10-12"
// seasons: "any" | "spring" | "summer" | "autumn" | "winter"
// category: creative | educational | outdoor | physical | sensory

const ACTIVITIES = [

  // ── ART & CRAFTS ─────────────────────────
  {
    name: "Volcano Painting",
    desc: "Mix baking soda into paint and watch it fizz and bubble on paper.",
    materials: ["baking soda", "paint", "paper", "vinegar"],
    duration: 40, category: "creative",
    interests: ["art", "science"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Leaf Print Art",
    desc: "Press leaves in paint and stamp them onto paper to make nature prints.",
    materials: ["leaves", "paint", "paper"],
    duration: 35, category: "creative",
    interests: ["art", "outdoors"], ages: ["2-3","4-6"], seasons: ["spring","summer","autumn"]
  },
  {
    name: "Rainbow Scratch Art",
    desc: "Colour paper in rainbow stripes, paint over in black, then scratch a picture through.",
    materials: ["crayons", "black paint", "toothpick", "paper"],
    duration: 50, category: "creative",
    interests: ["art"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Newspaper Sculptures",
    desc: "Scrunch, roll, and tape newspaper into animals or buildings. Paint when dry.",
    materials: ["newspaper", "tape", "paint"],
    duration: 60, category: "creative",
    interests: ["art","building"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Finger Painting",
    desc: "Create a colourful scene using only fingers and palms as brushes.",
    materials: ["finger paint", "large paper"],
    duration: 30, category: "sensory",
    interests: ["art"], ages: ["2-3","4-6"], seasons: ["any"]
  },
  {
    name: "Salt Dough Shapes",
    desc: "Mix flour, salt, and water into dough, shape it, bake, and paint when cool.",
    materials: ["flour", "salt", "water", "paint", "oven"],
    duration: 90, category: "creative",
    interests: ["art","cooking"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Watercolour Resist",
    desc: "Draw with a white crayon then paint over with watercolour — the hidden drawing appears!",
    materials: ["white crayon", "watercolour paint", "paper", "brush"],
    duration: 30, category: "creative",
    interests: ["art"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Collage Portrait",
    desc: "Cut magazine pictures and coloured paper to build a portrait or abstract face.",
    materials: ["old magazines", "scissors", "glue", "card"],
    duration: 45, category: "creative",
    interests: ["art","reading"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Bubble Wrap Printing",
    desc: "Paint bubble wrap and press it onto paper for a fun textured print.",
    materials: ["bubble wrap", "paint", "paper"],
    duration: 25, category: "creative",
    interests: ["art"], ages: ["2-3","4-6"], seasons: ["any"]
  },
  {
    name: "Comic Strip Story",
    desc: "Draw a 6-panel comic strip about anything — real or imaginary.",
    materials: ["paper", "pencils", "felt tips"],
    duration: 60, category: "creative",
    interests: ["art","drama","reading"], ages: ["7-9","10-12"], seasons: ["any"]
  },

  // ── SCIENCE & EDUCATIONAL ────────────────
  {
    name: "Rainbow Jar",
    desc: "Layer coloured sugar-water in a jar from most sugar to least — watch the rainbow stack.",
    materials: ["jars", "food colouring", "sugar", "water"],
    duration: 35, category: "educational",
    interests: ["science"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Shadow Clocks",
    desc: "Put a stick in the ground and mark where the shadow falls every hour — make a sun clock.",
    materials: ["stick", "chalk or stones", "sunny spot"],
    duration: 30, category: "educational",
    interests: ["science","outdoors"], ages: ["7-9","10-12"], seasons: ["spring","summer","autumn"]
  },
  {
    name: "Magnet Hunt",
    desc: "Go round the house testing objects — which ones are magnetic? Record your findings.",
    materials: ["magnet", "notebook", "pencil"],
    duration: 30, category: "educational",
    interests: ["science"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Baking Soda Rockets",
    desc: "Drop baking soda into vinegar in a plastic bottle and watch it fizz wildly.",
    materials: ["baking soda", "vinegar", "plastic bottle"],
    duration: 25, category: "educational",
    interests: ["science"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Egg Drop Challenge",
    desc: "Build a contraption from household materials to protect an egg dropped from a height.",
    materials: ["egg", "straws", "tape", "cotton wool", "plastic bag"],
    duration: 75, category: "educational",
    interests: ["science","building"], ages: ["10-12"], seasons: ["any"]
  },
  {
    name: "Homemade Lava Lamp",
    desc: "Fill a bottle with oil and water, add food colouring, drop in an antacid tablet — watch it bubble.",
    materials: ["bottle", "vegetable oil", "water", "food colouring", "antacid tablet"],
    duration: 30, category: "educational",
    interests: ["science"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Cloud in a Jar",
    desc: "Use hot water, ice, and hairspray to make a real cloud form inside a jar.",
    materials: ["glass jar", "hot water", "ice", "hairspray"],
    duration: 20, category: "educational",
    interests: ["science"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Seed Diary",
    desc: "Plant seeds in a glass jar lined with damp paper towel. Draw what you see each day.",
    materials: ["seeds", "glass jar", "paper towel", "notebook"],
    duration: 20, category: "educational",
    interests: ["science","outdoors","animals"], ages: ["4-6","7-9"], seasons: ["spring","summer"]
  },
  {
    name: "Bridge Building",
    desc: "Build the strongest bridge possible from paper only — test it by adding coins.",
    materials: ["paper", "scissors", "tape", "coins"],
    duration: 45, category: "educational",
    interests: ["science","building"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Homemade Slime",
    desc: "Mix glue, water, and borax-free activator to make stretchy, satisfying slime.",
    materials: ["PVA glue", "contact lens solution", "baking soda", "food colouring"],
    duration: 30, category: "sensory",
    interests: ["science","art"], ages: ["4-6","7-9"], seasons: ["any"]
  },

  // ── OUTDOOR ──────────────────────────────
  {
    name: "Bug Safari",
    desc: "Head outside with a magnifying glass and try to find and identify 5 different insects.",
    materials: ["magnifying glass", "notebook", "pencil"],
    duration: 60, category: "outdoor",
    interests: ["outdoors","animals","science"], ages: ["4-6","7-9","10-12"], seasons: ["spring","summer","autumn"]
  },
  {
    name: "Mud Kitchen",
    desc: "Set up an outdoor mud kitchen with old pots. Cook up imaginary mud pies and soups.",
    materials: ["old pots", "spoons", "water", "mud"],
    duration: 60, category: "sensory",
    interests: ["outdoors","cooking"], ages: ["2-3","4-6"], seasons: ["spring","summer","autumn"]
  },
  {
    name: "Cloud Watching",
    desc: "Lie on the grass and find shapes in the clouds. Draw your favourite three.",
    materials: ["blanket", "paper", "pencils"],
    duration: 30, category: "outdoor",
    interests: ["outdoors","art","science"], ages: ["4-6","7-9"], seasons: ["spring","summer","autumn"]
  },
  {
    name: "Nature Scavenger Hunt",
    desc: "Find a leaf, a feather, a rock, something yellow, something alive, and something old.",
    materials: ["list", "bag"],
    duration: 45, category: "outdoor",
    interests: ["outdoors","animals"], ages: ["4-6","7-9"], seasons: ["spring","summer","autumn"]
  },
  {
    name: "Garden Obstacle Course",
    desc: "Set up an outdoor course with hoops, cones, and rope. Time yourself on each run.",
    materials: ["rope", "hula hoops", "cones", "buckets"],
    duration: 60, category: "physical",
    interests: ["outdoors","sports"], ages: ["4-6","7-9","10-12"], seasons: ["spring","summer","autumn"]
  },
  {
    name: "Puddle Jumping Olympics",
    desc: "Find puddles and hold a jumping competition — furthest jump, biggest splash, most creative.",
    materials: ["rain boots", "puddles"],
    duration: 30, category: "physical",
    interests: ["outdoors","sports"], ages: ["2-3","4-6"], seasons: ["spring","winter","autumn"]
  },
  {
    name: "Nature Mandala",
    desc: "Collect leaves, petals, and twigs and arrange them in a beautiful circular pattern on the ground.",
    materials: ["natural objects from outside"],
    duration: 40, category: "creative",
    interests: ["outdoors","art"], ages: ["4-6","7-9","10-12"], seasons: ["spring","summer","autumn"]
  },
  {
    name: "Mini Pond Dipping",
    desc: "Use a net and jar to look at life in a puddle, pond, or ditch. Identify what you find.",
    materials: ["net", "clear jar", "water identification guide"],
    duration: 60, category: "outdoor",
    interests: ["outdoors","science","animals"], ages: ["7-9","10-12"], seasons: ["spring","summer","autumn"]
  },

  // ── PHYSICAL & SPORTS ────────────────────
  {
    name: "Indoor Obstacle Course",
    desc: "Cushions to leap, a tunnel of chairs, a balance beam of tape — go!",
    materials: ["cushions", "chairs", "masking tape"],
    duration: 50, category: "physical",
    interests: ["sports"], ages: ["2-3","4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Balloon Keep-Up",
    desc: "Keep a balloon in the air as long as possible — only using certain body parts each round.",
    materials: ["balloon"],
    duration: 30, category: "physical",
    interests: ["sports"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Dance Freeze",
    desc: "Dance to music — when it stops, everyone freezes. Last to move each round is out.",
    materials: ["music player"],
    duration: 25, category: "physical",
    interests: ["music","sports"], ages: ["2-3","4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Yoga Animals",
    desc: "Follow a kids' yoga video doing poses named after animals — downward dog, cat, butterfly.",
    materials: ["yoga mat or carpet", "device for video"],
    duration: 30, category: "physical",
    interests: ["sports","animals"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Sock Basketball",
    desc: "Roll socks into balls and shoot into laundry baskets at different distances.",
    materials: ["socks", "laundry basket", "masking tape"],
    duration: 30, category: "physical",
    interests: ["sports"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Skipping Challenge",
    desc: "Learn a new skipping trick or beat your personal best — count your longest run.",
    materials: ["skipping rope"],
    duration: 30, category: "physical",
    interests: ["sports","outdoors"], ages: ["7-9","10-12"], seasons: ["any"]
  },

  // ── COOKING & FOOD ───────────────────────
  {
    name: "Mini Baker",
    desc: "Mix and bake simple shortbread biscuits together — decorate with icing when cool.",
    materials: ["flour", "butter", "sugar", "icing"],
    duration: 70, category: "creative",
    interests: ["cooking"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Fruit Kebabs",
    desc: "Thread colourful fruit onto skewers in a pattern. Make a dipping sauce from yoghurt and honey.",
    materials: ["fruit", "skewers", "yoghurt", "honey"],
    duration: 25, category: "creative",
    interests: ["cooking"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Homemade Butter",
    desc: "Pour heavy cream into a jar and shake for 15 minutes — watch it become butter!",
    materials: ["heavy cream", "jar with lid", "salt", "bread"],
    duration: 25, category: "educational",
    interests: ["cooking","science"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Rainbow Smoothie",
    desc: "Blend a different coloured smoothie for each of 3 layers and gently pour into a glass.",
    materials: ["fruit", "yoghurt", "blender"],
    duration: 25, category: "creative",
    interests: ["cooking","science"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Sandwich Architecture",
    desc: "Build the tallest, most creative sandwich possible. Rules: it must be edible and it must balance.",
    materials: ["bread", "fillings of choice"],
    duration: 30, category: "creative",
    interests: ["cooking","building"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Iced Biscuit Decorating",
    desc: "Decorate plain biscuits with icing pens and sweets. Make a character or pattern.",
    materials: ["plain biscuits", "icing pens", "sweets"],
    duration: 40, category: "creative",
    interests: ["cooking","art"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },

  // ── MUSIC ────────────────────────────────
  {
    name: "Kitchen Band",
    desc: "Make instruments from kitchen items — pot drums, rice shakers, comb kazoo — and perform.",
    materials: ["pots", "spoons", "rice in tubs", "comb", "paper"],
    duration: 45, category: "creative",
    interests: ["music"], ages: ["2-3","4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Sound Walk",
    desc: "Walk slowly outside and list every sound you can hear. Record them in a nature sound diary.",
    materials: ["notebook", "pencil"],
    duration: 30, category: "educational",
    interests: ["music","outdoors"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Water Xylophone",
    desc: "Fill glasses with different amounts of water and tap with a spoon to play a tune.",
    materials: ["glasses", "water", "spoon"],
    duration: 30, category: "educational",
    interests: ["music","science"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Freeze Dance Party",
    desc: "Playlist DJ challenge — each person picks songs and the others must freeze when it stops.",
    materials: ["music player"],
    duration: 30, category: "physical",
    interests: ["music","sports"], ages: ["2-3","4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Compose a 5-Note Song",
    desc: "Using just 5 notes (do-re-mi-fa-so), compose a short original song and perform it.",
    materials: ["instrument or voice"],
    duration: 45, category: "creative",
    interests: ["music"], ages: ["7-9","10-12"], seasons: ["any"]
  },

  // ── BUILDING ────────────────────────────
  {
    name: "Cardboard City",
    desc: "Use cardboard boxes to build a mini city with roads, buildings, and parks.",
    materials: ["cardboard boxes", "scissors", "tape", "pens"],
    duration: 75, category: "creative",
    interests: ["building","art"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Spaghetti Tower",
    desc: "Build the tallest freestanding tower using only spaghetti and marshmallows.",
    materials: ["dried spaghetti", "marshmallows"],
    duration: 40, category: "educational",
    interests: ["building","science"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Marble Run",
    desc: "Build a marble run from cardboard tubes, tape, and boxes. Test and improve it.",
    materials: ["cardboard tubes", "tape", "marble", "boxes"],
    duration: 75, category: "educational",
    interests: ["building","science"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Lego Architect Challenge",
    desc: "Build the tallest tower that can hold a book on top without falling.",
    materials: ["Lego or building blocks", "book"],
    duration: 40, category: "educational",
    interests: ["building"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Pillow Fort Construction",
    desc: "Design and build the ultimate pillow fort with rooms and a secret entrance.",
    materials: ["pillows", "blankets", "chairs", "clothes pegs"],
    duration: 60, category: "creative",
    interests: ["building","drama"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Boat Float Test",
    desc: "Make boats from foil, corks, and sticks. Test which one carries the most pennies.",
    materials: ["foil", "corks", "sticks", "bowl of water", "pennies"],
    duration: 45, category: "educational",
    interests: ["building","science"], ages: ["4-6","7-9","10-12"], seasons: ["any"]
  },

  // ── DRAMA & ROLEPLAY ────────────────────
  {
    name: "Shadow Puppet Theatre",
    desc: "Cut out animal shapes, tape to sticks, and put on a play behind a sheet with a lamp behind.",
    materials: ["card", "sticks", "sheet", "lamp", "scissors"],
    duration: 60, category: "creative",
    interests: ["drama","art"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Dress-Up Fashion Show",
    desc: "Raid the dressing-up box (or wardrobe) and put on a full fashion show with commentary.",
    materials: ["clothes", "accessories"],
    duration: 45, category: "creative",
    interests: ["drama"], ages: ["2-3","4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Write a Mini Play",
    desc: "Write a 3-character play with a beginning, problem, and solution. Perform it for someone.",
    materials: ["paper", "pencil"],
    duration: 75, category: "creative",
    interests: ["drama","reading"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Puppet Show",
    desc: "Make simple sock puppets and perform a short story using them.",
    materials: ["old socks", "googly eyes", "glue", "felt"],
    duration: 60, category: "creative",
    interests: ["drama","art"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Improv Challenge",
    desc: "Pick a random object — you have 2 minutes to act out a scene where that object saves the world.",
    materials: ["random household object"],
    duration: 30, category: "creative",
    interests: ["drama"], ages: ["7-9","10-12"], seasons: ["any"]
  },

  // ── READING & WRITING ───────────────────
  {
    name: "Story Stones",
    desc: "Paint simple pictures on stones, then use them as prompts to tell a story by laying them out.",
    materials: ["smooth stones", "paint"],
    duration: 60, category: "creative",
    interests: ["reading","art"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Make a Mini Book",
    desc: "Fold 3 sheets of paper to make an 8-page book. Write and illustrate your own story.",
    materials: ["paper", "stapler", "pencils", "colouring pencils"],
    duration: 60, category: "creative",
    interests: ["reading","art"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Letter Writing",
    desc: "Write a proper letter to a grandparent, friend, or even a favourite author.",
    materials: ["paper", "envelope", "pens", "stamps"],
    duration: 40, category: "educational",
    interests: ["reading"], ages: ["7-9","10-12"], seasons: ["any"]
  },
  {
    name: "Mad Libs Stories",
    desc: "Take turns asking for nouns, verbs, and adjectives to fill gaps in a story. Read it aloud!",
    materials: ["paper", "pen"],
    duration: 30, category: "creative",
    interests: ["reading","drama"], ages: ["7-9","10-12"], seasons: ["any"]
  },

  // ── ANIMALS & NATURE ────────────────────
  {
    name: "Bird Feeder",
    desc: "Spread peanut butter on a pine cone, roll in bird seed, and hang it in the garden.",
    materials: ["pine cone", "peanut butter", "bird seed", "string"],
    duration: 20, category: "educational",
    interests: ["animals","outdoors"], ages: ["4-6","7-9"], seasons: ["any"]
  },
  {
    name: "Wildlife Sketch Book",
    desc: "Sit quietly outside for 20 minutes and sketch every living thing you see.",
    materials: ["sketchbook", "pencil"],
    duration: 40, category: "outdoor",
    interests: ["animals","outdoors","art"], ages: ["7-9","10-12"], seasons: ["spring","summer","autumn"]
  },
  {
    name: "Wormery",
    desc: "Layer soil and sand in a jar, add worms, and watch them tunnel over the week.",
    materials: ["jar", "soil", "sand", "worms", "dark paper"],
    duration: 30, category: "educational",
    interests: ["animals","science"], ages: ["4-6","7-9"], seasons: ["spring","summer","autumn"]
  },
  {
    name: "Animal Habitat Diorama",
    desc: "Choose an animal and build its habitat in a shoebox using craft materials.",
    materials: ["shoebox", "paint", "craft materials", "toy animals"],
    duration: 75, category: "creative",
    interests: ["animals","art","building"], ages: ["7-9","10-12"], seasons: ["any"]
  },

  // ── TODDLER SPECIFIC (2-3) ──────────────
  {
    name: "Sensory Bin",
    desc: "Fill a tray with rice, pasta, or sand and hide small toys inside to find.",
    materials: ["tray", "rice or pasta", "small toys"],
    duration: 30, category: "sensory",
    interests: ["science","animals"], ages: ["2-3"], seasons: ["any"]
  },
  {
    name: "Colour Sorting",
    desc: "Sort a mix of colourful objects into matching colour groups. Race the clock.",
    materials: ["colourful objects", "bowls"],
    duration: 20, category: "educational",
    interests: ["art","building"], ages: ["2-3","4-6"], seasons: ["any"]
  },
  {
    name: "Water Play",
    desc: "Set up bowls of water with cups, funnels, and spoons for free pouring and splashing play.",
    materials: ["bowls", "cups", "funnels", "spoons"],
    duration: 40, category: "sensory",
    interests: ["outdoors","science"], ages: ["2-3","4-6"], seasons: ["summer","spring"]
  },
  {
    name: "Sticker Scene",
    desc: "Draw a background (park, space, sea) and let the child place stickers to fill the scene.",
    materials: ["paper", "pens", "stickers"],
    duration: 25, category: "creative",
    interests: ["art"], ages: ["2-3","4-6"], seasons: ["any"]
  },

  // ── WINTER SPECIAL ──────────────────────
  {
    name: "Indoor Treasure Hunt",
    desc: "Write 6 clues that lead to the next — the final clue leads to a small prize or treat.",
    materials: ["paper", "pen"],
    duration: 45, category: "educational",
    interests: ["drama","reading"], ages: ["4-6","7-9","10-12"], seasons: ["winter","autumn","any"]
  },
  {
    name: "Origami Animals",
    desc: "Follow a beginner guide to fold paper into a crane, frog, or fox. Make a whole zoo.",
    materials: ["square paper"],
    duration: 45, category: "creative",
    interests: ["art","building","animals"], ages: ["7-9","10-12"], seasons: ["any"]
  }

];

// ── TIPS LIBRARY ───────────────────────────
const TIPS = [
  "Prep materials the night before so you're ready to dive right in.",
  "Let your child lead — if they take an activity in a new direction, go with it.",
  "Take photos of finished creations to build a memory scrapbook.",
  "Don't worry about mess — easy cleanup is part of the fun.",
  "Invite a neighbour's child for one activity to add a social element.",
  "Put on some background music to boost the creative atmosphere.",
  "Narrate what you're doing together — it builds language skills beautifully.",
  "Let your child explain their creation to you — it builds confidence.",
  "Repeat a favourite activity from last week — repetition deepens learning.",
  "Keep a 'curiosity jar' where your child drops questions to explore later.",
  "Screen-free time before the activity helps kids settle into creative play faster."
];
